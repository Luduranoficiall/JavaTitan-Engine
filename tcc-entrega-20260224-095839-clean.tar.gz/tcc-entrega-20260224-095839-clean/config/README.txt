Arquivo .env.tcc removido por seguranca.
